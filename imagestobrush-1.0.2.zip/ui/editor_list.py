import bpy


class IMG2BRUSH_UL_created_brushes(bpy.types.UIList):
    """Custom UIList for created brushes showing an inline checkbox."""
    def draw_item(
        self, context, layout, data, item, icon, active_data, active_propname, index
    ):
        #item.brush.asset_data.preview_ensure()
        #item.brush.preview_ensure()
        #print(item.brush.preview)
        settings = bpy.context.scene.img2brush_settings
        if settings.brush_force_previews:
            item.brush.texture.preview_ensure()
        
        layout.prop(item, "selected", text=item.brush.name, icon_value=item.brush.texture.preview.icon_id if item.brush.texture.preview else{k : i for i, k in enumerate(bpy.types.UILayout.bl_rna.functions["prop"].parameters["icon"].enum_items.keys())}["BRUSH_DATA"], )
        #layout.template_icon(icon_value=item.brush.asset_data.preview.icon_id)

        #layout.prop(item, "selected", text=item.brush.name, icon='BRUSH_DATA')